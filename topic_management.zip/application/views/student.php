<ol class="breadcrumb">
    <li><a href="<?php echo base_url('dashboard') ?>">Home</a></li> 
    <li class="active">Manage Student</li>
</ol>

<div class="panel panel-default">
    <div class="panel-body">  	
        <fieldset>
            <legend>Manage Student</legend>    	

            <div id="messages"></div>

            <div class="pull pull-right">
                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#addStudent" id="addStudentModelBtn"> 
                    <i class="glyphicon glyphicon-plus-sign"></i> Add Student
                </button>
            </div>

            <br /> <br /> <br />    	

            <table id="manageStudentTable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Contact</th>    				
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>	

        </fieldset>	
    </div>
</div>

<!-- add student -->
<div class="modal fade" tabindex="-1" role="dialog" id="addStudent">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Student</h4>
            </div>

            <form class="form-horizontal" method="post" id="createStudentForm" action="student/create" enctype="multipart/form-data">

                <div class="modal-body create-modal">

                    <div id="add-student-messages"></div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="fname" class="col-sm-4 control-label">First Name : </label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="fname" name="fname" placeholder="First Name"  />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="lname" class="col-sm-4 control-label">Last Name : </label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="lname" name="lname" placeholder="Last Name"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="dob" class="col-sm-4 control-label">DOB: </label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="dob" name="dob" placeholder="Date of Birth" />
                                    </div>
                                </div>                                
                                <div class="form-group">
                                    <label for="contact" class="col-sm-4 control-label">Contact: </label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="contact" name="contact" placeholder="Contact" />
                                    </div>
                                </div>	
                                <div class="form-group">
                                    <label for="email" class="col-sm-4 control-label">Email: </label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="email" name="email" placeholder="Email" />
                                    </div>
                                </div>	
                                <div class="form-group">
                                    <label for="password" class="col-sm-4 control-label">Password: </label>
                                    <div class="col-sm-8">
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="confirmpassword" class="col-sm-4 control-label">Confirm Password: </label>
                                    <div class="col-sm-8">
                                        <input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Confirm Password" />
                                    </div>
                                </div>
                            </div>
                            <!-- /col-md-6 -->

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="photo" class="col-sm-4 control-label">Photo: </label>
                                    <div class="col-sm-8">					      	
                                        <!-- the avatar markup -->
                                        <div id="kv-avatar-errors-1" class="center-block" style="max-width:500px;display:none"></div>							
                                        <div class="kv-avatar center-block" style="width:100%">
                                            <input type="file" id="photo" name="photo" class="file-loading"/>								        
                                        </div>
                                    </div>
                                </div>
                            </div>				 
                            <!-- /col-md-4 -->
                        </div>
                        <!-- /col-md-12 -->

                    </div>
                    <!-- /row -->
                </div>
                <!-- /modal-body -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- edit student -->
<div class="modal fade" tabindex="-1" role="dialog" id="updateStudentModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Student</h4>
            </div>

            <div class="modal-body edit-modal">

                <div id="edit-student-messages"></div>

                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Photo</a></li>
                    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Personal Detail</a></li>	    
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="home">
                        <br /> 

                        <form class="form-horizontal" method="post" id="updateStudentPhotoForm" action="student/updatePhoto" enctype="multipart/form-data">

                            <div class="row">
                                <div class="col-md-12">
                                    <div id="edit-upload-image-message"></div>

                                    <div class="col-md-6">
                                        <center>
                                            <img src="" id="student_photo" alt="Student Photo" class="img-thumbnail upload-photo" />
                                        </center>								
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="editPhoto" class="col-sm-4 control-label">Photo: </label>
                                            <div class="col-sm-8">					      	
                                                <!-- the avatar markup -->
                                                <div id="kv-avatar-errors-1" class="center-block" style="max-width:500px;display:none"></div>							
                                                <div class="kv-avatar center-block" style="width:100%">
                                                    <input type="file" id="editPhoto" name="editPhoto" class="file-loading"/>								        
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <center>
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                                </center>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- /col-md-6 -->
                                </div>
                                <!-- /col-md-12 -->
                            </div>
                            <!-- /row -->

                        </form>
                    </div>
                    <!-- /tab panel of image -->

                    <div role="tabpanel" class="tab-pane" id="profile">

                        <br /> 
                        <form class="form-horizontal" method="post" action="student/updateInfo" id="updateStudentInfoForm">
                            <div class="row">

                                <div class="col-md-12">
                                    <div id="edit-personal-student-message"></div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="editFname" class="col-sm-4 control-label">First Name : </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="editFname" name="editFname" placeholder="First Name" />
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="editLname" class="col-sm-4 control-label">Last Name : </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="editLname" name="editLname" placeholder="Last Name"/>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="editDob" class="col-sm-4 control-label">DOB: </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="editDob" name="editDob" placeholder="Date of Birth" />
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="editContact" class="col-sm-4 control-label">Contact: </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="editContact" name="editContact" placeholder="Contact" />
                                            </div>
                                        </div>	
                                        <div class="form-group">
                                            <label for="editEmail" class="col-sm-4 control-label">Email: </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="editEmail" name="editEmail" placeholder="Email" />
                                            </div>
                                        </div>	
                                    </div>
                                    <!-- /col-md-6 -->
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <center>
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                            </center>
                                        </div>
                                    </div>
                                </div>
                                <!-- /col-md-12 -->

                            </div>
                            <!-- /row -->				  	
                        </form>

                    </div>	    	
                    <!-- /tab-panel of student information -->
                </div>


            </div>
            <!-- /modal-body -->      

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- remove student -->
<div class="modal fade" tabindex="-1" role="dialog" id="removeStudentModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Remove Student</h4>
            </div>
            <div class="modal-body">
                <div id="remove-messages"></div>
                <p>Do you really want to remove ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="removeStudentBtn">Delete</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



<script type="text/javascript" src="<?php echo base_url('../custom/js/student.js') ?>"></script>