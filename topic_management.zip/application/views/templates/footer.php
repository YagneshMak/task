</div> <!--/container-fluid-->


<!-- boostrap js -->
  <script type="text/javascript" src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <!-- datatables js -->
  <script type="text/javascript" src="../assets/datatables/media/js/jquery.dataTables.min.js"></script>
  <!-- fileinput js -->
  <script type="text/javascript" src="../assets/fileinput/js/fileinput.min.js"></script>

  <!-- full calendar -->
  <script type="text/javascript" src="../assets/fullcalendar/moment.min.js"></script>  
  <script type="text/javascript" src="../assets/fullcalendar/fullcalendar.min.js"></script>  

  <!-- keith calendar -->
  <script type="text/javascript" src="../assets/keith-calendar/jquery.calendars.js"></script> 
  <script type="text/javascript" src="../assets/keith-calendar/jquery.calendars.plus.js"></script> 
  <script type="text/javascript" src="../assets/keith-calendar/jquery.plugin.js"></script> 
  <script type="text/javascript" src="../assets/keith-calendar/jquery.calendars.picker.js"></script>
  <script type="text/javascript" src="../assets/keith-calendar/jquery.calendars.picker.js"></script>

  


</body>
</html>