
<div class="row">
    <?php if ($loggedInUserType == "Admin") { ?>        
        <div class="col-md-3">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <a href="student" style="color:white;">
                        Total Students : <span class="badge"><?php echo $countTotalStudent; ?></span>	
                    </a>				
                </div>			
            </div>
        </div>

        <div class="col-md-3">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <a href="topic">
                        Total Topics : <span class="badge"><?php echo $countTotalTopic; ?></span>	 	
                    </a>

                </div>			
            </div>
        </div>

        <div class="col-md-3">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <a href="topic">
                        Total Assigned Topics : <span class="badge"><?php echo $countTotalAssignedTopic; ?></span>		
                    </a>

                </div>			
            </div>
        </div>
        <div class="col-md-3">
            <div class="panel panel-warning">
                <div class="panel-heading">
                    <a href="topic">
                        Total Pending Topics : <span class="badge"><?php echo $countTotalPendingTopic; ?></span>	
                    </a>
                </div>			
            </div>
        </div>
    <?php } else { ?>            
        <div class="col-md-3">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <a href="assignedtopic">
                        Total Assigned Topics : <span class="badge"><?php echo $countTotalAssignedTopic; ?></span>		
                    </a>

                </div>			
            </div>
        </div>
        <div class="col-md-3">
            <div class="panel panel-warning">
                <div class="panel-heading">
                    <a href="assignedtopic">
                        Total Pending Topics : <span class="badge"><?php echo $countTotalPendingTopic; ?></span>	
                    </a>
                </div>			
            </div>
        </div>
    <?php } ?>    
</div>
<div class="row">
    <div class="col-md-5">
        <div class="panel panel-default">
            <div class="panel-heading"> <i class="glyphicon glyphicon-user"></i> User Info</div>
            <div class="panel-body">
                <div class="col-md-4"><img src="../<?php echo $userData['image']; ?>" alt="<?php echo $userData['fname'].' '.$userData['lname']; ?>" width="150" /></div>
                <div class="col-md-8">
                    Wel Come <b><?php echo ($loggedInUserType == "Admin") ? "Admin" : $userData['fname'].' '.$userData['lname']; ?></b>                            
                </div>
            </div>	
        </div>
    </div>
    <div class="col-md-7">
        <div class="panel panel-default">
            <div class="panel-heading"> <i class="glyphicon glyphicon-calendar"></i> Calendar</div>
            <div class="panel-body">
                <div id="calendar"></div>
            </div>	
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $("#topNavDashboard").addClass('active');
        $("#calendar").fullCalendar();
    });
</script>

