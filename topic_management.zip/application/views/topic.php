<ol class="breadcrumb">
    <li><a href="<?php echo base_url('dashboard') ?>">Home</a></li> 
    <li class="active">Manage Topic</li>
</ol>

<div class="panel panel-default">
    <div class="panel-body">  	
        <fieldset>
            <legend>Manage Topic</legend>    	

            <div id="messages"></div>

            <div class="pull pull-right">
                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#addTopic" id="addTopicModelBtn"> 
                    <i class="glyphicon glyphicon-plus-sign"></i> Add Topic
                </button>
            </div>

            <br /> <br /> <br />    	

            <table id="manageTopicTable" class="table table-bordered">
                <thead>
                    <tr>                       
                        <th>Title</th>
                        <th>Assigned User</th>
                        <th>Add Date</th>
                        <th>Status</th>    				
                        <th>Action</th>
                    </tr>
                </thead>
            </table>	

        </fieldset>	
    </div>
</div>

<!-- add topic -->
<div class="modal fade" tabindex="-1" role="dialog" id="addTopic">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Topic</h4>
            </div>
            <form class="form-horizontal" method="post" id="createTopicForm" action="topic/create" enctype="multipart/form-data">
                <div class="modal-body create-modal">
                    <div id="add-topic-messages"></div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-10">
                                <div class="form-group">
                                    <label for="title" class="col-sm-4 control-label">Title : </label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="title" name="title" placeholder="Title" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description" class="col-sm-4 control-label">Description : </label>
                                    <div class="col-sm-8">
                                        <textarea class="form-control" id="description" name="description" style="height: 200px;" placeholder="Description" ></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="status" class="col-sm-4 control-label">Status : </label>
                                    <div class="col-sm-8">
                                        <select name="status" id="status" class="form-control">
                                            <option value="0" selected="selected">Pending</option>                                            
                                        </select>                                        
                                    </div>
                                </div>
                            </div>
                            <!-- /col-md-6 -->
                        </div>
                        <!-- /col-md-12 -->
                    </div>
                    <!-- /row -->
                </div>
                <!-- /modal-body -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- edit topic -->
<div class="modal fade" tabindex="-1" role="dialog" id="updateTopicModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Topic</h4>
            </div>
            <div class="modal-body edit-modal">
                <form class="form-horizontal" method="post" action="topic/updateInfo" id="updateTopicInfoForm">
                    <div class="modal-body create-modal">
                        <div id="edit-personal-topic-message"></div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-10">
                                    <div class="form-group">
                                        <label for="editTitle" class="col-sm-4 control-label">Title : </label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="editTitle" name="editTitle" placeholder="Title" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="editDescription" class="col-sm-4 control-label">Description : </label>
                                        <div class="col-sm-8">
                                            <textarea class="form-control" id="editDescription" name="editDescription" style="height: 200px;" placeholder="Description" ></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="editStatus" class="col-sm-4 control-label">Status : </label>
                                        <div class="col-sm-8">
                                            <select name="editStatus" id="editStatus" class="form-control">
                                                <option value="0" selected="selected">Pending</option>                                        
                                            </select>                                        
                                        </div>
                                    </div>
                                </div>
                                <!-- /col-md-6 -->
                            </div>
                            <!-- /col-md-12 -->
                        </div>
                        <!-- /row -->
                    </div>
                    <!-- /modal-body -->                
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
            <!-- /modal-body -->      
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- edit topic -->
<div class="modal fade" tabindex="-1" role="dialog" id="assignTopicModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Assign Topic</h4>
            </div>
            <div class="modal-body edit-modal">
                <form class="form-horizontal" method="post" action="topic/assignTopicInfo" id="assignTopicInfoForm">
                    <div class="modal-body create-modal">
                        <div id="assign-personal-topic-message"></div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-10">
                                    <div class="form-group">
                                        <?php
                                        if (!empty($studentData)) {
                                            ?>
                                            <label for="assign_to_student" class="col-sm-4 control-label">Assign To Student : </label>
                                            <div class="col-sm-8">
                                                <select name="assign_to_student" id="assign_to_student" class="form-control">
                                                    <?php foreach ($studentData as $key => $value) { ?>
                                                        <option value="<?php echo $value['id'] ?>"><?php echo $value['fname'] . " " . $value['lname'] . " <" . $value['fname'] . "> "; ?></option>
                                                    <?php } ?>
                                                </select>                                        
                                            </div>
                                        <?php } else { ?>
                                            <div class="col-sm-10">
                                                <div class="alert alert-warning alert-dismissible" role="alert">
                                                    There is no any student for assign topic. Please add student first!
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <!-- /col-md-6 -->
                            </div>
                            <!-- /col-md-12 -->
                        </div>
                        <!-- /row -->
                    </div>
                    <!-- /modal-body -->                
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <?php if (!empty($studentData)) { ?>
                            <button type="submit" class="btn btn-primary">Assign</button>
                        <?php } ?>
                    </div>
                </form>
            </div>
            <!-- /modal-body -->      
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- remove topic -->
<div class="modal fade" tabindex="-1" role="dialog" id="removeTopicModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Remove Topic</h4>
            </div>
            <div class="modal-body">
                <div id="remove-messages"></div>
                <p>Do you really want to remove ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="removeTopicBtn">Delete</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- remove topic -->
<div class="modal fade" tabindex="-1" role="dialog" id="approveTopicModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Approve Topic</h4>
            </div>
            <div class="modal-body">
                <div id="remove-messages"></div>
                <p>Approve this topic by click on Approve button</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="approveTopicBtn">Approve</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript" src="<?php echo base_url('../custom/js/topic.js') ?>"></script>