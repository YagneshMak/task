<ol class="breadcrumb">
    <li><a href="<?php echo base_url('dashboard') ?>">Home</a></li> 
    <li class="active">Manage Assigned Topic</li>
</ol>

<div class="panel panel-default">
    <div class="panel-body">  	
        <fieldset>
            <legend>Manage Assigned Topic</legend>    	

            <div id="messages"></div>

            <br /> <br /> <br />    	

            <table id="manageAssignedTopicTable" class="table table-bordered">
                <thead>
                    <tr>                       
                        <th>Title</th>
                        <th>Add Date</th>
                        <th>Status</th>    				
                        <th>Action</th>
                    </tr>
                </thead>
            </table>	

        </fieldset>	
    </div>
</div>

<!-- edit topic -->
<div class="modal fade" tabindex="-1" role="dialog" id="updateTopicModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Assigned Topic</h4>
            </div>
            <div class="modal-body edit-modal">
                <form class="form-horizontal" method="post" action="assignedtopic/updateInfo" id="updateTopicInfoForm">
                    <div class="modal-body create-modal">
                        <div id="edit-personal-topic-message"></div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-10">
                                    <div class="form-group">
                                        <label for="editTitle" class="col-sm-4 control-label">Title : </label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="editTitle" name="editTitle" placeholder="Title" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="editDescription" class="col-sm-4 control-label">Description : </label>
                                        <div class="col-sm-8">
                                            <textarea class="form-control" id="editDescription" name="editDescription" style="height: 200px;" placeholder="Description" ></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="editStatus" class="col-sm-4 control-label">Status : </label>
                                        <div class="col-sm-8">
                                            <select name="editStatus" id="editStatus" class="form-control">
                                                <option value="0" selected="selected">Pending</option>                                                
                                            </select>                                        
                                        </div>
                                    </div>
                                </div>
                                <!-- /col-md-6 -->
                            </div>
                            <!-- /col-md-12 -->
                        </div>
                        <!-- /row -->
                    </div>
                    <!-- /modal-body -->                
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
            <!-- /modal-body -->      
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script type="text/javascript" src="<?php echo base_url('../custom/js/assignedtopic.js') ?>"></script>