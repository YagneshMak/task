<?php

class AssignedTopic extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $this->isNotLoggedIn();

        // loading the topic model
        $this->load->model('model_assignedtopic');

        // loading the form validation library
        $this->load->library('form_validation');
    }

    /*
     * ------------------------------------
     * retrieves topic information 
     * ------------------------------------
     */

    public function fetchAssignedTopicData() {

        $loggedInUserId = $this->getLoggedInUserId();
        $statusArr = array('0' => 'Pending', '1' => 'Approved', '2' => 'Assigned');
        $topicData = $this->model_assignedtopic->fetchAssignedTopicData($loggedInUserId);
        $result = array('data' => array());

        foreach ($topicData as $key => $value) {
            $status = $value['status'];
            $user_id = $value['user_id'];
            $button = '<!-- Single button -->
					<div class="btn-group">
					  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					    Action <span class="caret"></span>
					  </button>
					  <ul class="dropdown-menu">
                                          <li><a type="button" data-toggle="modal" data-target="#updateTopicModal" onclick="editTopic(' . $value['id'] . ')" style="cursor:pointer;"> <i class="glyphicon glyphicon-edit"></i> Edit</a></li>
					  </ul>
					</div>';

            $result['data'][$key] = array(
                $value['title'],
                $value['add_date'],
                $statusArr[$status],
                $button
            );
        } // /foreach        
        echo json_encode($result);
    }

    /*
     * ------------------------------------
     * updates topic information
     * ------------------------------------
     */

    public function updateInfo($topicId = null) {
        $loggedInUserId = $this->getLoggedInUserId();
        if ($this->model_assignedtopic->checkTopicUpdatedToday($loggedInUserId) == false) {
            if ($topicId) {
                $validator = array('success' => false, 'messages' => array());

                $validate_data = array(
                    array(
                        'field' => 'editTitle',
                        'label' => 'Title',
                        'rules' => 'required'
                    ),
                    array(
                        'field' => 'editDescription',
                        'label' => 'Description',
                        'rules' => 'required'
                    )
                );

                $this->form_validation->set_rules($validate_data);
                $this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');

                if ($this->form_validation->run() === true) {
                    $updateInfo = $this->model_assignedtopic->updateInfo($topicId);
                    if ($updateInfo == true) {
                        $validator['success'] = true;
                        $validator['messages'] = "Successfully Updated";
                    } else {
                        $validator['success'] = false;
                        $validator['messages'] = "Error while inserting the information into the database";
                    }
                } else {
                    $validator['success'] = false;
                    foreach ($_POST as $key => $value) {
                        $validator['messages'][$key] = form_error($key);
                    }
                } // /else         
            }
        } else {
            $validator['success'] = false;
            $validator['messages'] = "Sorry, Today you have already updated a topic.";
        }
        echo json_encode($validator);
    }
}
