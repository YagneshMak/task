<?php

class Pages extends MY_Controller {

    public function view($page = 'login') {

        if (!file_exists(APPPATH . 'views/' . $page . '.php')) {
            // Whoops, we don't have a page for that!
            show_404();
        }
        $data['title'] = ucfirst($page); // Capitalize the first letter
        $data['loggedInUserType'] = ($this->isStudentLoggedIn()) ? 'Student' : 'Admin';
        $data['loggedInUserId'] = $this->getLoggedInUserId();
        if ($page == 'student' || $page == 'topic') {

            $this->load->model('model_student');
            $data['studentData'] = $this->model_student->fetchStudentData();

            $this->load->model('model_topic');
            $data['topicData'] = $this->model_topic->fetchTopicData();            
        }

        if ($page == 'setting' || $page == 'dashboard') {
            $this->load->model('model_users');
            $this->load->library('session');
            $userId = $this->session->userdata('id');
            $data['userData'] = $this->model_users->fetchUserData($userId);
        }

        if ($page == 'dashboard') {
            $this->load->model('model_student');
            $this->load->model('model_topic');
            
            $data['countTotalStudent'] = $this->model_student->countTotalStudent();
            $data['countTotalTopic'] = $this->model_topic->countTotalTopic();
            if ($this->isStudentLoggedIn()) {
                $this->load->model('model_assignedtopic');
                $data['countTotalAssignedTopic'] = $this->model_assignedtopic->countTotalAssignedTopic($this->getLoggedInUserId());
                $data['countTotalPendingTopic'] = $this->model_assignedtopic->countTotalPendingTopic($this->getLoggedInUserId());
            } else {
                $data['countTotalAssignedTopic'] = $this->model_topic->countTotalAssignedTopic();
                $data['countTotalPendingTopic'] = $this->model_topic->countTotalPendingTopic();
            }
        }

        if ($page == 'login') {
            $this->isLoggedIn();
            $this->load->view($page, $data);
        } else {
            $this->isNotLoggedIn();

            $this->load->view('templates/header', $data);
            $this->load->view($page, $data);
            $this->load->view('templates/footer', $data);
        }
    }

}
