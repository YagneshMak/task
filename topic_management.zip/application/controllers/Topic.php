<?php

class Topic extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $this->isNotLoggedIn();

        // loading the topic model
        $this->load->model('model_topic');

        // loading the form validation library
        $this->load->library('form_validation');
    }

    /*
     * ------------------------------------
     * inserts the topics information
     * into the database 
     * ------------------------------------
     */

    public function create() {
        $validator = array('success' => false, 'messages' => array());

        $validate_data = array(
            array(
                'field' => 'title',
                'label' => 'Title',
                'rules' => 'required'
            )
        );

        $this->form_validation->set_rules($validate_data);
        $this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');       
        if ($this->form_validation->run() === true) {
            $create = $this->model_topic->create();
            if ($create == true) {
                $validator['success'] = true;
                $validator['messages'] = "Successfully added";
            } else {
                $validator['success'] = false;
                $validator['messages'] = "Error while inserting the information into the database";
            }
        } else {
            $validator['success'] = false;
            foreach ($_POST as $key => $value) {
                $validator['messages'][$key] = form_error($key);
            }
        } // /else

        echo json_encode($validator);
    }

    /*
     * ------------------------------------
     * retrieves topic information 
     * ------------------------------------
     */
    
    public function fetchTopicData($topicId = null) {        
        $statusArr = array('0'=>'Pending','1'=>'Approved','2'=>'Assigned');
        if ($topicId) {
            $result = $this->model_topic->fetchTopicData($topicId);
        } else {
            $topicData = $this->model_topic->fetchTopicData();
            
            $result = array('data' => array());
            foreach ($topicData as $key => $value) {
                $status = $value['status'];
                $user_id = $value['user_id'];
                $assignData = (isset($user_id) && $user_id > 0) ? $this->model_topic->getAssignedUserName($value['user_id']) : array("name"=>"Unassigned");
                $button = '<!-- Single button -->
					<div class="btn-group">
					  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					    Action <span class="caret"></span>
					  </button>
					  <ul class="dropdown-menu">';
                                        if(isset($user_id) && $user_id == 0){ 
                                        $button .='<li><a type="button" data-toggle="modal" data-target="#assignTopicModal" onclick="assignTopic(' . $value['id'] . ')" style="cursor:pointer;"> <i class="glyphicon glyphicon-user"></i> Assign</a></li>';
                                        }
                                        $button .='<li><a type="button" data-toggle="modal" data-target="#updateTopicModal" onclick="editTopic(' . $value['id'] . ')" style="cursor:pointer;"> <i class="glyphicon glyphicon-edit"></i> Edit</a></li>                                            
					    <li><a type="button" data-toggle="modal" data-target="#removeTopicModal" onclick="removeTopic(' . $value['id'] . ')" style="cursor:pointer;"> <i class="glyphicon glyphicon-trash"></i> Remove</a></li>		    
                                            
                                          <li><a type="button" data-toggle="modal" data-target="#approveTopicModal" onclick="approveTopic(' . $value['id'] . ')" style="cursor:pointer;"> <i class="glyphicon glyphicon-eye-open"></i> Approve</a></li>    
					  </ul>
					</div>';

                $result['data'][$key] = array(
                    $value['title'],
                    $assignData['name'],
                    $value['add_date'],
                    $statusArr[$status],
                    $button
                );
            } // /foreach
        }
        echo json_encode($result);
    }

    /*
     * ------------------------------------
     * updates topic information
     * ------------------------------------
     */

    public function updateInfo($topicId = null) {
        if ($topicId) {
            $validator = array('success' => false, 'messages' => array());

            $validate_data = array(
                array(
                    'field' => 'editTitle',
                    'label' => 'Title',
                    'rules' => 'required'
                )
            );

            $this->form_validation->set_rules($validate_data);
            $this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');

            if ($this->form_validation->run() === true) {
                $updateInfo = $this->model_topic->updateInfo($topicId);
                if ($updateInfo == true) {
                    $validator['success'] = true;
                    $validator['messages'] = "Successfully Updated";
                } else {
                    $validator['success'] = false;
                    $validator['messages'] = "Error while inserting the information into the database";
                }
            } else {
                $validator['success'] = false;
                foreach ($_POST as $key => $value) {
                    $validator['messages'][$key] = form_error($key);
                }
            } // /else

            echo json_encode($validator);
        }
    }
    
    /*
     * ------------------------------------
     * assign topic information
     * ------------------------------------
     */

    public function assignTopicInfo($topicId = null) {
        if ($topicId) {
            $validator = array('success' => false, 'messages' => array());

            $validate_data = array(
                array(
                    'field' => 'assign_to_student',
                    'label' => 'Student',
                    'rules' => 'required'
                )
            );

            $this->form_validation->set_rules($validate_data);
            $this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');

            if ($this->form_validation->run() === true) {
                $updateInfo = $this->model_topic->assignTopicInfo($topicId);
                if ($updateInfo == true) {
                    $validator['success'] = true;
                    $validator['messages'] = "Successfully Assigned";
                } else {
                    $validator['success'] = false;
                    $validator['messages'] = "Error while inserting the information into the database";
                }
            } else {
                $validator['success'] = false;
                foreach ($_POST as $key => $value) {
                    $validator['messages'][$key] = form_error($key);
                }
            } // /else

            echo json_encode($validator);
        }
    }

    /*
     * ------------------------------------
     * removes topic information 
     * ------------------------------------
     */

    public function remove($topicId = null) {
        $validator = array('success' => false, 'messages' => array());

        if ($topicId) {
            $remove = $this->model_topic->remove($topicId);
            if ($remove) {
                $validator['success'] = true;
                $validator['messages'] = "Successfully Removed";
            } else {
                $validator['success'] = false;
                $validator['messages'] = "Error while removing the information";
            } // /else
        } // /if

        echo json_encode($validator);
    }
    
    /*
     * ------------------------------------
     * removes topic information 
     * ------------------------------------
     */

    public function approveTopic($topicId = null) {
        $validator = array('success' => false, 'messages' => array());

        if ($topicId) {
            $remove = $this->model_topic->approveTopic($topicId);
            if ($remove) {
                $validator['success'] = true;
                $validator['messages'] = "Successfully Approved";
            } else {
                $validator['success'] = false;
                $validator['messages'] = "Error while removing the information";
            } // /else
        } // /if

        echo json_encode($validator);
    }
}
