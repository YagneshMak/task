<?php 

class MY_Controller extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
	}

	public function isLoggedIn()
	{
		$this->load->library('session');

		if($this->session->userdata('logged_in') === true) {
			redirect('../dashboard');
		}
	}	

	public function isNotLoggedIn()
	{
		$this->load->library('session');

		if($this->session->userdata('logged_in') !== true) {
			redirect('../../');
		}
	}
        public function isStudentLoggedIn()
	{
		$this->load->library('session');
		if($this->session->userdata('userType') == '1') {
                    return true;
		}
                return false;
	}
        public function getLoggedInUserId()
	{
		$this->load->library('session');
                return $this->session->userdata('id');
	}

}