<?php

class Model_Topic extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /*
     * ------------------------------------
     * inserts the topics information
     * into the database 
     * ------------------------------------
     */

    public function create() {
        $insert_data = array(
            'title' => $this->input->post('title'),
            'description' => $this->input->post('description'),
            'status' => $this->input->post('status')
        );
        $this->db->set('add_date', 'NOW()', FALSE);
        $status = $this->db->insert('topic', $insert_data);
        return ($status == true ? true : false);
    }

    /*
     * ------------------------------------
     * retrieves topic information 
     * ------------------------------------
     */
    
    public function fetchTopicData($topicId = null) {
        if ($topicId) {
            $sql = "SELECT * FROM topic WHERE id = ?";
            $query = $this->db->query($sql, array($topicId));
            $result = $query->row_array();
            return $result;
        }
        $assign = ($this->input->get('assign') == '1') ? $this->input->get('assign') : "";
        $pending = ($this->input->get('pending') == '1') ? $this->input->get('pending') : "";
        $AdvQry = "";
        if($assign == '1'){
            $AdvQry .= " AND status = '2' AND user_id > '0'";
        }
        if($pending == '1'){
            $AdvQry .= " AND status = '0'";
        }
        $sql = "SELECT * FROM topic where 1".$AdvQry;        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        return $result;
    }

    /*
     * ------------------------------------
     * updates topic information
     * ------------------------------------
     */

    public function updateInfo($topicId = null) {
        if ($topicId) {
            $update_data = array(
                'title' => $this->input->post('editTitle'),
                'description' => $this->input->post('editDescription'),
                'status' => $this->input->post('editStatus')
            );
            $this->db->where('id', $topicId);
            $query = $this->db->update('topic', $update_data);
            return ($query === true ? true : false);
        }
    }

     /*
     * ------------------------------------
     * assign topic information
     * ------------------------------------
     */

    public function assignTopicInfo($topicId = null) {
        if ($topicId) {
            $update_data = array(
                'user_id' => $this->input->post('assign_to_student'),
                'status' => '2'
            );
            $this->db->where('id', $topicId);
            $query = $this->db->update('topic', $update_data);
            return ($query === true ? true : false);
        }
    }
    
    /*
     * ------------------------------------
     * removes topic information 
     * ------------------------------------
     */

    public function remove($topicId = null) {
        if ($topicId) {
            $this->db->where('id', $topicId);
            $result = $this->db->delete('topic');
            return ($result === true ? true : false);
        } // /if
    }

    /*
     * ------------------------------------
     * approve topic information 
     * ------------------------------------
     */

    public function approveTopic($topicId = null) {
        if ($topicId) {
            $update_data = array(                
                'status' => '1'
            );
            $this->db->where('id', $topicId);
            $query = $this->db->update('topic', $update_data);
            return ($query === true ? true : false);
        }
    }    
    
    /*
     * ------------------------------------
     * count total topic information 
     * ------------------------------------
     */

    public function countTotalTopic() {
        $sql = "SELECT * FROM topic";
        $query = $this->db->query($sql);
        return $query->num_rows();
    }
    
    /*
     * ------------------------------------
     * count total Assigned topic information 
     * ------------------------------------
     */

    public function countTotalAssignedTopic() {
        $sql = "SELECT * FROM topic where status = '2' AND user_id > '0'";
        $query = $this->db->query($sql);
        return $query->num_rows();
    }
    
    /*
     * ------------------------------------
     * count total Pending topic information 
     * ------------------------------------
     */

    public function countTotalPendingTopic() {
        $sql = "SELECT * FROM topic where status = ?";
        $query = $this->db->query($sql,array('0'));
        return $query->num_rows();
    }

    /*
     * ------------------------------------
     * retrieves Assigned User Name
     * ------------------------------------
     */
    
    public function getAssignedUserName($userId = null) {
        $sql = "SELECT CONCAT(fname,' ',lname) as name FROM user where id = ?";
        $query = $this->db->query($sql, array($userId));
        $result = $query->row_array();
        return $result;        
    }
    
    /*
     * ------------------------------------
     * retrieves Users for assign topic
     * ------------------------------------
     */

    public function fetchStudentList() {
        $sql = "SELECT * FROM user";
        $query = $this->db->query($sql);
        $result = $query->result_array();
        return $result;
    }

}
