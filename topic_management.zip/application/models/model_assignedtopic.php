<?php

class Model_AssignedTopic extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /*
     * ------------------------------------
     * retrieves topic information 
     * ------------------------------------
     */

    public function fetchAssignedTopicData($userId = null) {
        $sql = "SELECT * FROM topic where user_id = ?";
        $query = $this->db->query($sql,array($userId));
        $result = $query->result_array();
        return $result;
    }

    /*
     * ------------------------------------
     * updates topic information
     * ------------------------------------
     */

    public function updateInfo($topicId = null) {
        if ($topicId) {
            $update_data = array(
                'title' => $this->input->post('editTitle'),
                'description' => $this->input->post('editDescription'),
                'status' => $this->input->post('editStatus'),
                'is_student_updated' => '1'
            );
            $this->db->set('student_updated_date', 'NOW()', FALSE);
            $this->db->where('id', $topicId);
            $query = $this->db->update('topic', $update_data);
            return ($query === true ? true : false);
        }
    }

    /*
     * ------------------------------------
     * Check If Topic Data Fill By Today
     * ------------------------------------
     */

    public function checkTopicUpdatedToday($userId = null) {
        $sql = "SELECT * FROM topic where user_id = ? AND is_student_updated = ? AND date(student_updated_date) = date(NOW())";
        $query = $this->db->query($sql,array($userId,'1'));
        $result = $query->num_rows();        
        return ($result > 0) ? true : false;
    }
    
    /*
     * ------------------------------------
     * count total Assigned topic information 
     * ------------------------------------
     */

    public function countTotalAssignedTopic($userId = null) {
        $sql = "SELECT * FROM topic where user_id=? AND status = ?";
        $query = $this->db->query($sql,array($userId,'2'));
        return $query->num_rows();
    }
    
    /*
     * ------------------------------------
     * count total Pending topic information 
     * ------------------------------------
     */
    public function countTotalPendingTopic($userId = null) {
        $sql = "SELECT * FROM topic where user_id=? AND is_student_updated = ?";
        $query = $this->db->query($sql,array($userId,'0'));
        return $query->num_rows();
    }
}
