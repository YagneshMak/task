<?php 

class Model_Student extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	/*
	*------------------------------------
	* inserts the students information
	* into the database 
	*------------------------------------
	*/
	public function create($img_url)
	{
		if($img_url == '') {
			$img_url = 'assets/images/default/default_avatar.png';
		} 

		$insert_data = array(
			'fname' 		=> $this->input->post('fname'),
			'lname'			=> $this->input->post('lname'),
			'image'			=> $img_url,
			'date_of_birth'         => $this->input->post('dob'),
			'password'		=> md5($this->input->post('password')),
			'contact'		=> $this->input->post('contact'),
			'email'			=> $this->input->post('email'),			
			'user_type'		=> '1'
		);
                $this->db->set('register_date', 'NOW()', FALSE);
		$status = $this->db->insert('user', $insert_data);		
		return ($status == true ? true : false);
	}

	/*
	*------------------------------------
	* retrieves student information 
	*------------------------------------
	*/
	public function fetchStudentData($studentId = null)	
	{
		if($studentId) {
			$sql = "SELECT * FROM user WHERE id = ? AND user_type = ?";
			$query = $this->db->query($sql, array($studentId,'1'));
			$result = $query->row_array();
			return $result;
		}

		$sql = "SELECT * FROM user where user_type = ?";
		$query = $this->db->query($sql,array('1'));
		$result = $query->result_array();
		return $result;
	}

	/*
	*------------------------------------
	* updates student information
	*------------------------------------
	*/
	public function updateInfo($studentId = null)
	{
		if($studentId) {
			$update_data = array(
				'fname' 			=> $this->input->post('editFname'),
				'lname' 			=> $this->input->post('editLname'),
				'date_of_birth'     => $this->input->post('editDob'),
				'contact'			=> $this->input->post('editContact'),
				'email'				=> $this->input->post('editEmail')				
			);

			$this->db->where('id', $studentId);
			$query = $this->db->update('user', $update_data);
			
			return ($query === true ? true : false);
		}			
	}

	/*
	*------------------------------------
	* updates student information
	*------------------------------------
	*/
	public function updatePhoto($studentId = null, $imageUrl = null)
	{
		if($studentId && $imageUrl) {
			$update_data = array(
				'image' 	=> $imageUrl
			);

			$this->db->where('id', $studentId);
			$query = $this->db->update('user', $update_data);
			
			return ($query === true ? true : false);
		}			
	}

	/*
	*------------------------------------
	* removes student information 
	*------------------------------------
	*/
	public function remove($studentId = null)
	{
		if($studentId) {
			$this->db->where('id', $studentId);
			$result = $this->db->delete('user');
			return ($result === true ? true: false); 
		} // /if
	}

	/*
	*------------------------------------
	* count total student information 
	*------------------------------------
	*/	
	public function countTotalStudent() 
	{
		$sql = "SELECT * FROM user where user_type='1'";
		$query = $this->db->query($sql);
		return $query->num_rows();
	}
}